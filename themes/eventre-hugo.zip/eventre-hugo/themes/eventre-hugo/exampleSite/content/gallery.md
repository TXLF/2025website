---
title : "Our Gallery"
page_header_bg : "images/background/page-title-bg.jpg"
date: 2020-03-14T15:40:24+06:00
description : "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maiores, velit."
draft : false
layout : "gallery"
gallery_items:
- name : "gallery item"
  image: "images/gallery/gallery-popup-one.jpg"
  categories: ["meeting", "concert"]
  
- name : "gallery item"
  image: "images/gallery/gallery-popup-two.jpg"
  categories: ["events", "meeting"]
  
- name : "gallery item"
  image: "images/gallery/gallery-popup-three.jpg"
  categories: ["party", "events"]
  
- name : "gallery item"
  image: "images/gallery/gallery-popup-four.jpg"
  categories: ["meeting", "concert"]
  
- name : "gallery item"
  image: "images/gallery/gallery-popup-five.jpg"
  categories: ["events", "concert", "party"]
  
- name : "gallery item"
  image: "images/gallery/gallery-popup-six.jpg"
  categories: ["party", "concert"]
---