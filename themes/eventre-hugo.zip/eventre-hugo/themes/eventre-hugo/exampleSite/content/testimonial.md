---
title : "Testimonial"
page_header_bg : "images/background/page-title-bg.jpg"
date: 2020-03-14T15:40:24+06:00
description : "this is meta description"
draft : false
layout : "testimonial"

#### Testimonial ####
testimonial:
  enable: true
  title: "What People _Say?_"
  content : "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti aliquid vero harum rerum voluptates, ab, ullam."
  testimonial_items:
  - name : "Espen Brunberg"
    designation : "Web Developer"
    image : "images/speakers/speaker-thumb-three.jpg"
    content : "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis voluptate modi sunt placeat in vel illo dolorem, atque maxime voluptates optio fugit iure cum ipsa quo quaerat! Veritatis, modi. Laudantium provident deleniti earum voluptas delectus, labore dolor dolorem amet expedita."
    
  - name : "Kaite Stricker"
    designation : "Web Developer"
    image : "images/speakers/speaker-thumb-one.jpg"
    content : "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis voluptate modi sunt placeat in vel illo dolorem, atque maxime voluptates optio fugit iure cum ipsa quo quaerat! Veritatis, modi. Laudantium provident deleniti earum voluptas delectus, labore dolor dolorem amet expedita."
    
  - name : "Adam Smith"
    designation : "Web Developer"
    image : "images/speakers/speaker-thumb-five.jpg"
    content : "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis voluptate modi sunt placeat in vel illo dolorem, atque maxime voluptates optio fugit iure cum ipsa quo quaerat! Veritatis, modi. Laudantium provident deleniti earum voluptas delectus, labore dolor dolorem amet expedita."
    
  - name : "Espen Brunberg"
    designation : "Web Developer"
    image : "images/speakers/speaker-thumb-three.jpg"
    content : "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis voluptate modi sunt placeat in vel illo dolorem, atque maxime voluptates optio fugit iure cum ipsa quo quaerat! Veritatis, modi. Laudantium provident deleniti earum voluptas delectus, labore dolor dolorem amet expedita."
    
  - name : "Kaite Stricker"
    designation : "Web Developer"
    image : "images/speakers/speaker-thumb-one.jpg"
    content : "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis voluptate modi sunt placeat in vel illo dolorem, atque maxime voluptates optio fugit iure cum ipsa quo quaerat! Veritatis, modi. Laudantium provident deleniti earum voluptas delectus, labore dolor dolorem amet expedita."
    
  - name : "Adam Smith"
    designation : "Web Developer"
    image : "images/speakers/speaker-thumb-five.jpg"
    content : "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis voluptate modi sunt placeat in vel illo dolorem, atque maxime voluptates optio fugit iure cum ipsa quo quaerat! Veritatis, modi. Laudantium provident deleniti earum voluptas delectus, labore dolor dolorem amet expedita."
---