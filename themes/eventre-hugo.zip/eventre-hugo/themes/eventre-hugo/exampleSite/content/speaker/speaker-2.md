---
title : "Jonathan Franco"
page_header_bg : "images/background/page-title-bg.jpg"
date: 2020-03-14T15:40:24+06:00
designation: "Project Manager"
image: "images/speakers/speaker-two.jpg"
description : "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maiores, velit."
draft : false
social:
- name: "facebook"
  icon: "fa-facebook"
  link: "#"
- name: "twitter"
  icon: "fa-twitter"
  link: "#"
- name: "linkedin"
  icon: "fa-linkedin"
  link: "#"
- name: "instagram"
  icon: "fa-instagram"
  link: "#"
- name: "skype"
  icon: "fa-skype"
  link: "#"

personal_info:
  enable : true
  title : "Personal Information"
  content : "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi explicabo suscipit deleniti voluptatum quos nostrum iure doloremque cupiditate voluptatem a enim eaque quod perspiciatis repudiandae, mollitia adipisci ea, quidem eveniet consequatur veniam error. Adipisci, suscipit corporis repellat, soluta vitae deserunt."
  bulletpoints:
  - "Morbi fermentum felis nec"
  - "Fermentum felis nec gravida tempus."
  - "Morbi fermentum felis nec"
  - "Fermentum felis nec gravida tempus."
  - "Morbi fermentum felis nec"
  - "Fermentum felis nec gravida tempus."


skills:
  enable : true
  title : "Personal Skills"
  content : "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi explicabo suscipit deleniti voluptatum quos nostrum iure doloremque."
  skillbars:
  - name: "Wordpress"
    percentage: "90%"
  - name: "PHP"
    percentage: "75%"
  - name: "Javascript"
    percentage: "60%"
  - name: "HTML"
    percentage: "80%"
---
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusm tempor incididunt ut labore
dolore magna aliqua enim ad minim veniam quis nostrud.laboris nisi ut aliquip ex ea commodo consequat.
Duis aute irure dolor in reprehenderit in voluptate velit esse.

Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni
dolores eos qui ratione voluptatem sequi nesciunt.

Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur